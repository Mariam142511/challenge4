#!/usr/bin/env python
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Pose2D
import time

class AutoPathPublisher(Node):
    def __init__(self):
        super().__init__('Generator_node')
        self.publisher = self.create_publisher(Pose2D, 'point', 10)
        self.get_logger().info('Pointer generator node started (auto mode)')

        # Puntos para las 4 figuras
        self.triang = [(0.5, 0.0), (0.25, 0.5), (0.0, 0.0)]
        self.cuad = [(0.5, 0.5), (0.0, 1.0), (-0.5, 0.5), (0.0, 0.0)]
        self.pent = [(-0.1, 0.25), (0.125, 0.45), (0.35, 0.25), (0.25, 0.0), (0.0, 0.0)]
        self.hex = [(-0.15, 0.25), (0.0, 0.5), (0.25, 0.5), (0.4, 0.25), (0.2, 0.0), (0.0, 0.0)]

        # Concatenar todas las trayectorias
        self.trayectoria = self.triang + self.cuad + self.pent + self.hex

        # Publicar puntos con temporizador
        self.index = 0
        self.timer = self.create_timer(4.0, self.publish_next_point)

    def publish_next_point(self):
        if self.index < len(self.trayectoria):
            x, y = self.trayectoria[self.index]
            point = Pose2D()
            point.x = x
            point.y = y
            point.theta = 0.0
            self.publisher.publish(point)
            self.get_logger().info(f'Objetivo publicado: ({x:.2f}, {y:.2f})')
            self.index += 1
        else:
            self.get_logger().info('Todas las trayectorias completadas.')
            self.destroy_timer(self.timer)

def main(args=None):
    rclpy.init(args=args)
    node = AutoPathPublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()