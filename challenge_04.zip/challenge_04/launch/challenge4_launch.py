from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():

    odometry_node = Node(
        package='challenge_04',
        executable='odometry',
        output='screen',
    )

    controller_node = Node(
        package='challenge_04',
        executable='controller10',
        name='controller10',
        parameters=['params.yaml'],  # <- Cargar parámetros desde YAML
        output='screen',
    )

    path_node = Node(
        package='challenge_04',
        executable='path3',
        name='Generator_node',
        parameters=['params.yaml'],  # <- Cargar figura desde YAML
        output='screen',
    )

    camera_node = Node(
        package='challenge_04',
        executable='cameraPub',
        output='screen',
    )

    semaforo_node = Node(
        package='challenge_04',
        executable='susImage4',
        output='screen',
    )

    # angular_node opcional
    # angular_node = Node(
    #     package='challenge_04',
    #     executable='camPath4',
    #     output='screen',
    # )

    return LaunchDescription([
        odometry_node,
        controller_node,
        path_node,
        camera_node,
        semaforo_node,
        # angular_node
    ])